#include "ExprPredictor.h"

int main( int argc, char* argv[] )
{
    // command line processing
    string seqFile, exprFile, motifFile, factorExprFile, coopFile, factorInfoFile, repressionFile, parFile;
    string outFile;                               // output file
    string factor_thr_file;
    double coopDistThr = 50;
    double factorIntSigma = 50.0;                 // sigma parameter for the Gaussian interaction function
    double repressionDistThr = 250;
    int maxContact = 1;
    double eTF = 0.60;

    string free_fix_indicator_filename;
    ExprPredictor::one_qbtm_per_crm = false;
    ExprPar::one_qbtm_per_crm = false;
    ExprFunc::one_qbtm_per_crm = false;

    ExprPredictor::nAlternations = 2;
    ExprPredictor::nSimplexIters = 2;
    ExprPredictor::window_train_iter = 2;
    ExprPredictor::nGradientIters = 2;
    ExprPredictor::nRandStarts = 0;
    ExprPredictor::min_delta_f_SSE = 1.0E-10;
    ExprPredictor::min_delta_f_Corr = 1.0E-10;

	ExprPar::is_bounded_search = false;
    for ( int i = 1; i < argc; i++ )
    {
        if ( !strcmp( "-s", argv[ i ] ) )
            seqFile = argv[ ++i ];
        else if ( !strcmp( "-e", argv[ i ] ) )
            exprFile = argv[ ++i ];
        else if ( !strcmp( "-m", argv[ i ] ) )
            motifFile = argv[ ++i ];
        else if ( !strcmp( "-f", argv[ i ] ) )
            factorExprFile = argv[ ++i ];
        else if ( !strcmp( "-o", argv[ i ] ) )
            ExprPredictor::modelOption = getModelOption( argv[++i] );
        else if ( !strcmp( "-c", argv[ i ] ) )
            coopFile = argv[ ++i ];
        else if ( !strcmp( "-i", argv[ i ] ) )
            factorInfoFile = argv[ ++i ];
        else if ( !strcmp( "-r", argv[ i ] ) )
            repressionFile = argv[ ++i ];
        else if ( !strcmp( "-oo", argv[ i ] ) )
            ExprPredictor::objOption = getObjOption( argv[++i] );
        else if ( !strcmp( "-fo", argv[i] ) )
            outFile = argv[++i];
        else if ( !strcmp( "-p", argv[i] ) )
            parFile = argv[++i];
        else if ( !strcmp( "-ct", argv[i] ) )
            coopDistThr = atof( argv[++i] );
        else if ( !strcmp( "-sigma", argv[i] ) )
            factorIntSigma = atof( argv[++i] );
        else if ( !strcmp( "-rt", argv[i] ) )
            repressionDistThr = atof( argv[++i] );
        else if ( !strcmp( "-na", argv[i] ) )
            ExprPredictor::nAlternations = atoi( argv[++i] );
        else if ( !strcmp( "-ff", argv[i] ) )
            free_fix_indicator_filename = argv[++i];
        else if ( !strcmp( "-bs", argv[i] ) ){
		double bs_val = atof( argv[++i] );
		ExprPar::is_bounded_search = bs_val > 0 ? true : false;
		cout << "Set is_bounded_search = " << ExprPar::is_bounded_search << endl;
	}
            
    }
    
    double gcContent = 0.5;
    FactorIntType intOption = BINARY;             // type of interaction function
    ExprPar::searchOption = CONSTRAINED;          // search option: unconstrained; constrained.
    ExprPar::estBindingOption = 1;

    int rval;
    vector< vector< double > > data;              // buffer for reading matrix data
    vector< string > labels;                      // buffer for reading the labels of matrix data
    string factor1, factor2;                      // buffer for reading factor pairs

    // read the sequences
    vector< Sequence > seqs;
    vector< string > seqNames;
    rval = readSequences( seqFile, seqs, seqNames );
    assert( rval != RET_ERROR );
    int nSeqs = seqs.size();
	
	cout << "Read " << nSeqs << " sequence(s)" << endl;
	cout << "Lengths: " << endl;
	for( int _temp_i = 0; _temp_i < nSeqs; _temp_i++ ){
		cout << "\t" << seqNames[ _temp_i ] << "\t" << (seqs[_temp_i]).size() << endl;
	}

    // read the expression data
    vector< string > condNames;
    rval = readMatrix( exprFile, labels, condNames, data );
    assert( rval != RET_ERROR );
    Matrix exprData( data );
    int nConds = exprData.nCols();
	
	cout << "Read " << nConds << " bins of data" << endl;

	//create stripe expression data from the vector "data"
	vector < vector < vector < double > > > stripe_expr_data;
	create_stripe_expression_data( stripe_expr_data, data );
		

	cout << "Gene expression split into stripe expressions" << endl;
	for( int _temp_i = 0; _temp_i < nSeqs; _temp_i++ ){
		cout << "Expression for gene " << _temp_i << " split into " << stripe_expr_data[_temp_i].size() << " stripes" << endl;
	}
    // read the motifs
    vector< Motif > motifs;
    vector< string > motifNames;
    vector< double > background = createNtDistr( gcContent );
    rval = readMotifs( motifFile, background, motifs, motifNames );
    assert( rval != RET_ERROR );
    int nFactors = motifs.size();

	cout << "Read " << nFactors << " motifs" << endl;
	cout << "Motif lengths: " << endl;
	for( int _temp_i = 0; _temp_i < nFactors; _temp_i++ ){
		cout << "\t" << motifNames[ _temp_i ] << "\t" << motifs[_temp_i].length() << endl;
	}

    // factor name to index mapping
    map< string, int > factorIdxMap;
    for ( int i = 0; i < motifNames.size(); i++ )
    {
        factorIdxMap[motifNames[i]] = i;
    }

    // read the factor expression data
    labels.clear();
    data.clear();
    rval = readMatrix( factorExprFile, labels, condNames, data );
    assert( rval != RET_ERROR );

    Matrix factorExprData( data );
    assert( factorExprData.nCols() == nConds && factorExprData.nRows() == nFactors );
	cout << "Read factor expression data" << endl;
    // read the cooperativity matrix
    int num_of_coop_pairs = 0;
    IntMatrix coopMat( nFactors, nFactors, false );
    if ( !coopFile.empty() )
    {
        ifstream fcoop( coopFile.c_str() );
        if ( !fcoop )
        {
            cerr << "Cannot open the cooperativity file " << coopFile << endl;
            exit( 1 );
        }
        while ( fcoop >> factor1 >> factor2 )
        {
            assert( factorIdxMap.count( factor1 ) && factorIdxMap.count( factor2 ) );
            int idx1 = factorIdxMap[factor1];
            int idx2 = factorIdxMap[factor2];
            if( coopMat( idx1, idx2 ) == false && coopMat( idx2, idx1 ) == false )
            {
                coopMat( idx1, idx2 ) = true;
                coopMat( idx2, idx1 ) = true;
                num_of_coop_pairs ++;
            }
        }
    }
	cout << "Number of cooperative pairs of TFs: " << num_of_coop_pairs << endl;
    // read the roles of factors
    vector< bool > actIndicators( nFactors, false );
    vector< bool > repIndicators( nFactors, false );
    if ( !factorInfoFile.empty() )
    {
        ifstream finfo( factorInfoFile.c_str() );
        if ( !finfo )
        {
            cerr << "Cannot open the factor information file " << factorInfoFile << endl;
            exit( 1 );
        }
        string name;
        int i = 0, actRole, repRole;
        while ( finfo >> name >> actRole >> repRole )
        {
            assert( name == motifNames[i] );
            if ( actRole ) actIndicators[i] = true;
            if ( repRole ) repIndicators[i] = true;
            i++;
        }
	assert( i == nFactors );
    }
    // read the repression matrix
    IntMatrix repressionMat( nFactors, nFactors, false );
    if ( !repressionFile.empty() )
    {
        ifstream frepr( repressionFile.c_str() );
        if ( !frepr )
        {
            cerr << "Cannot open the repression file " << repressionFile << endl;
            exit( 1 );
        }
        while ( frepr >> factor1 >> factor2 )
        {
            assert( factorIdxMap.count( factor1 ) && factorIdxMap.count( factor2 ) );
            int idx1 = factorIdxMap[factor1];
            int idx2 = factorIdxMap[factor2];
            repressionMat( idx1, idx2 ) = true;
        }
    }

    //read the free fix indicator information
    vector <bool> indicator_bool;
    indicator_bool.clear();
    if( !free_fix_indicator_filename.empty() )
    {
        ifstream free_fix_indicator_file ( free_fix_indicator_filename.c_str() );
        while( !free_fix_indicator_file.eof( ) )
        {
            int indicator_var;
            free_fix_indicator_file >> indicator_var;
            assert ( indicator_var == 0 || indicator_var == 1 );
            indicator_bool.push_back( indicator_var );
        }
    }
    else
    {
        //for binding weights, coop pairs and transcriptional effects
        for( int index = 0; index < nFactors + num_of_coop_pairs + nFactors; index++ )
        {
            indicator_bool.push_back( true );
        }
        //for q_btm parameter
        indicator_bool.push_back( true );
        //for the energyThrFactors:
        for( int index = 0; index < nFactors; index ++ )
        {
            indicator_bool.push_back( true );
        }
    }

	// print the parameters for running the analysis
    cout << "Parameters for running the program: " << endl;
    cout << "Model = " << getModelOptionStr( ExprPredictor::modelOption ) << endl;
    if ( ExprPredictor::modelOption == CHRMOD_UNLIMITED )
    {
        cout << "Repression_Distance_Threshold = " << repressionDistThr << endl;
    }
    cout << "Objective_Function = " << getObjOptionStr( ExprPredictor::objOption ) << endl;
    if ( !coopFile.empty() )
    {
        cout << "Interaction_Model = " << getIntOptionStr( intOption ) << endl;
        cout << "Interaction_Distance_Threshold = " << coopDistThr << endl;
        if ( intOption == GAUSSIAN ) cout << "Sigma = " << factorIntSigma << endl;
    }
    cout << "Search_Option = " << getSearchOptionStr( ExprPar::searchOption ) << endl;
    
	// create the expression predictor
    FactorIntFunc* intFunc;
    if ( intOption == BINARY ) intFunc = new FactorIntFuncBinary( coopDistThr );
    else if ( intOption == GAUSSIAN ) intFunc = new FactorIntFuncGaussian( coopDistThr, factorIntSigma );
    else
    {
        cerr << "Interaction Function is invalid " << endl; exit( 1 );
    }
    
	ExprPredictor* predictor = new ExprPredictor( seqs, /*seqLengths,*/ exprData, stripe_expr_data, motifs, factorExprData, intFunc, coopMat, actIndicators, repIndicators, repressionMat, repressionDistThr, indicator_bool, motifNames );
    // read the initial parameter values
    ExprPar par_init( nFactors, nSeqs );
    if ( !parFile.empty() )
    {
        rval = par_init.load( parFile, num_of_coop_pairs );
        if ( rval == RET_ERROR )
        {
            cerr << "Cannot read parameters from " << parFile << endl;
            exit( 1 );
        }
    }

    predictor->train( par_init );

    cout << "Estimated values of parameters:" << endl;
    ExprPar par = predictor->getPar();
    par.print( cout, motifNames, coopMat );
    cout << "Performance = " << setprecision( 5 ) << (( ExprPredictor::objOption == SSE ) ? predictor->getObj() : -predictor->getObj())  << endl;

    // print the predictions
    ofstream fout( outFile.c_str() );
    if ( !fout )
    {
        cerr << "Cannot open file " << outFile << endl;
        exit( 1 );
    }
    fout << "Rows\t" << condNames << endl;

    for ( int i = 0; i < nSeqs; i++ )
    {
    	vector< double > targetExprs (nConds, 0);
	predictor->get_solution( targetExprs, par, i );
        vector< double > observedExprs = exprData.getRow( i );

        fout << seqNames[i] << "\t" << observedExprs << endl;
        fout << seqNames[i] << "\t" << targetExprs << endl;
/*
        double pgp_score;
        double corr_score;
        double beta;                              //= par.betas[ i ];
        double error;
        if( ExprPredictor::objOption == SSE )
        {
            error = sqrt( least_square( targetExprs, observedExprs, beta ) / nConds );
        }
        if( ExprPredictor::objOption == PGP )
        {
            pgp_score = pgp( targetExprs, observedExprs, beta );
        }
        if( ExprPredictor::objOption == CORR )
        {
            corr_score = corr( targetExprs, observedExprs, beta );
        }
                                                  // predictions
        for ( int j = 0; j < nConds; j++ ) fout << "\t" << ( beta * targetExprs[j] );
        fout << endl;

        // print the agreement bewtween predictions and observations
        cout << seqNames[i] << "\t" << beta << "\t";
        if ( ExprPredictor::objOption == SSE )
        {
            cout << error << endl;
        }
        else if ( ExprPredictor::objOption == CORR )
            cout << corr_score << endl;
        else if ( ExprPredictor::objOption == PGP )
            cout << pgp_score << endl;*/
    }
    return 0;
}
