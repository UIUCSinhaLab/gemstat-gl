#include <gsl/gsl_math.h>
#include <gsl/gsl_multimin.h>

#include "ExprPredictor.h"

ModelType getModelOption( const string& modelOptionStr )
{
    if ( toupperStr( modelOptionStr ) == "DIRECT" ) return DIRECT;
    if ( toupperStr( modelOptionStr ) == "CHRMOD_UNLIMITED" ) return CHRMOD_UNLIMITED;

    cerr << "modelOptionStr is not a valid model option" << endl;
    exit(1);
}


string getModelOptionStr( ModelType modelOption )
{
    if ( modelOption == DIRECT ) return "Direct";
    if ( modelOption == CHRMOD_UNLIMITED ) return "ChrMod_Unlimited";

    return "Invalid";
}


string getIntOptionStr( FactorIntType intOption )
{
    if ( intOption == BINARY ) return "Binary";
    if ( intOption == GAUSSIAN ) return "Gaussian";

    return "Invalid";
}


ObjType getObjOption( const string& objOptionStr )
{
    if ( toupperStr( objOptionStr ) == "SSE" ) return SSE;
    if ( toupperStr( objOptionStr ) == "CORR" ) return CORR;
    if ( toupperStr( objOptionStr ) == "PGP" ) return PGP;

    cerr << "objOptionStr is not a valid option of objective function" << endl;
    exit(1);
}


string getObjOptionStr( ObjType objOption )
{
    if ( objOption == SSE ) return "SSE";
    if ( objOption == CORR ) return "Corr";
    if ( objOption == PGP ) return "PGP";

    return "Invalid";
}


string getSearchOptionStr( SearchType searchOption )
{
    if ( searchOption == UNCONSTRAINED ) return "Unconstrained";
    if ( searchOption == CONSTRAINED ) return "Constrained";

    return "Invalid";
}


double FactorIntFuncBinary::compFactorInt( double normalInt, double dist, bool orientation ) const
{
    assert( dist >= 0 );

    double spacingTerm = ( dist < distThr ? normalInt : 1.0 );
    double orientationTerm = orientation ? 1.0 : orientationEffect;
    return spacingTerm * orientationTerm;
}


double FactorIntFuncGaussian::compFactorInt( double normalInt, double dist, bool orientation ) const
{
    assert( dist >= 0 );

    double GaussianInt = dist < distThr ? normalInt * exp( - ( dist * dist ) / ( 2.0 * sigma * sigma ) ) : 1.0;
    return max( 1.0, GaussianInt );
}


double FactorIntFuncGeometric::compFactorInt( double normalInt, double dist, bool orientation ) const
{
    assert( dist >= 0 );

    double spacingTerm = max( 1.0, dist <= distThr ? normalInt : normalInt * pow( spacingEffect, dist - distThr ) );
    double orientationTerm = orientation ? 1.0 : orientationEffect;
    return spacingTerm * orientationTerm;
}


ExprPar::ExprPar( int _nFactors, int _nSeqs ) : factorIntMat(), min_factorIntMat(), max_factorIntMat()
{
    assert( _nFactors > 0 );

    for ( int i = 0; i < _nFactors; i++ )
    {
        maxBindingWts.push_back( ExprPar::default_weight );
    }

    factorIntMat.setDimensions( _nFactors, _nFactors );
    
    factorIntMat.setAll( ExprPar::default_interaction );

    for ( int i = 0; i < _nFactors; i++ )
    {
        double defaultEffect = ExprPar::default_effect_Thermo;
        txpEffects.push_back( defaultEffect );
        repEffects.push_back( ExprPar::default_repression );
    }

    nSeqs = _nSeqs;
    double basalTxp_val = ExprPar::default_basal_Thermo;
    basalTxps.push_back( basalTxp_val );

    for( int i = 0; i < _nFactors; i++ )
    {
        energyThrFactors.push_back( ExprPar::default_energyThrFactors );
    }
 
 	//set up constraints on min and max
    min_factorIntMat.setDimensions( _nFactors, _nFactors );
    max_factorIntMat.setDimensions( _nFactors, _nFactors );
    min_factorIntMat.setAll( ExprPar::min_interaction );
    max_factorIntMat.setAll( ExprPar::max_interaction );
    for ( int i = 0; i < _nFactors; i++ )
    {
        min_weights.push_back( ExprPar::min_weight );
        max_weights.push_back( ExprPar::max_weight );
	min_effects_Thermo.push_back( ExprPar::min_effect_Thermo );
	max_effects_Thermo.push_back( ExprPar::max_effect_Thermo );
	min_repressions.push_back( ExprPar::min_repression );
	max_repressions.push_back( ExprPar::max_repression );
        min_energyThrFactors_.push_back( ExprPar::min_energyThrFactors );
        max_energyThrFactors_.push_back( ExprPar::max_energyThrFactors );
    }
    min_basals_Thermo.push_back( ExprPar::min_basal_Thermo );
    max_basals_Thermo.push_back( ExprPar::max_basal_Thermo );
}

ExprPar::ExprPar( const vector< double >& _maxBindingWts, const Matrix& _factorIntMat, const vector< double >& _txpEffects, const vector< double >& _repEffects, const vector < double >& _basalTxps, int _nSeqs, const vector <double>& _energyThrFactors ) : maxBindingWts( _maxBindingWts ), factorIntMat( _factorIntMat ), txpEffects( _txpEffects ), repEffects( _repEffects ), basalTxps( _basalTxps ), nSeqs( _nSeqs ), energyThrFactors( _energyThrFactors )
{
    if ( !factorIntMat.isEmpty() ) assert( factorIntMat.nRows() == maxBindingWts.size() && factorIntMat.isSquare() );
    assert( txpEffects.size() == maxBindingWts.size() && repEffects.size() == maxBindingWts.size() );
    assert( basalTxps.size() == 1 );
    int _nFactors = maxBindingWts.size();
    min_factorIntMat.setDimensions( _nFactors, _nFactors );
    max_factorIntMat.setDimensions( _nFactors, _nFactors );
    min_factorIntMat.setAll( ExprPar::min_interaction );
    max_factorIntMat.setAll( ExprPar::max_interaction );
    for ( int i = 0; i < _nFactors; i++ )
    {
        min_weights.push_back( ExprPar::min_weight );
        max_weights.push_back( ExprPar::max_weight );
	min_effects_Thermo.push_back( ExprPar::min_effect_Thermo );
	max_effects_Thermo.push_back( ExprPar::max_effect_Thermo );
	min_repressions.push_back( ExprPar::min_repression );
	max_repressions.push_back( ExprPar::max_repression );
        min_energyThrFactors_.push_back( ExprPar::min_energyThrFactors );
        max_energyThrFactors_.push_back( ExprPar::max_energyThrFactors );
    }
    min_basals_Thermo.push_back( ExprPar::min_basal_Thermo );
    max_basals_Thermo.push_back( ExprPar::max_basal_Thermo );
    if( ExprPar::is_bounded_search ){
    	for(int i = 0; i < _nFactors; i++){
		for(int j = 0; j < _nFactors; j++){
			min_factorIntMat(i,j ) = factorIntMat(i,j) / 2;
			max_factorIntMat(i,j ) = factorIntMat(i,j) * 2;
		}
        	min_weights[ i ] = maxBindingWts[ i ] / 2;
        	max_weights[ i ] = maxBindingWts[ i ] * 2;
		min_effects_Thermo[ i ] = txpEffects[ i ] / 2;
		max_effects_Thermo[ i ] = txpEffects[ i ] * 2;
		min_repressions[ i ] = repEffects[ i ] / 2;
		max_repressions[ i ] = repEffects[ i ] * 2;
		min_energyThrFactors_[ i ] = energyThrFactors[ i ] / 2;
		max_energyThrFactors_[ i ] = ((energyThrFactors[ i ] * 2) > 1) ? 0.99 : energyThrFactors[ i ] * 2;
	}
	min_basals_Thermo[ 0 ] = basalTxps[ 0 ] / 2;
	max_basals_Thermo[ 0 ] = basalTxps[ 0 ] * 2;
    }
}


ExprPar::ExprPar( const vector< double >& pars, const IntMatrix& coopMat, const vector< bool >& actIndicators, const vector< bool >& repIndicators, int _nSeqs, const ExprPar& other ) : factorIntMat(), min_factorIntMat(), max_factorIntMat()
{
    int _nFactors = actIndicators.size();
    nSeqs = _nSeqs;
    assert( coopMat.isSquare() && coopMat.nRows() == _nFactors );
    assert( repIndicators.size() == _nFactors );
    int counter = 0;

    // set maxBindingWts
    if ( estBindingOption )
    {
        for ( int i = 0; i < _nFactors; i++ )
        {
            double weight = searchOption == CONSTRAINED ? exp( inverse_infty_transform( pars[counter++], log( other.min_weights[i] ), log( other.max_weights[i] ) ) ) : exp( pars[counter++] );
            maxBindingWts.push_back( weight );
        }
    }
    else
    {
        for ( int i = 0; i < _nFactors; i++ ) maxBindingWts.push_back( ExprPar::default_weight );
    }

    // set the interaction matrix
    factorIntMat.setDimensions( _nFactors, _nFactors );
    for ( int i = 0; i < _nFactors; i++ )
    {
        for ( int j = 0; j <= i; j++ )
        {
            if ( coopMat( i, j ) )
            {
                double interaction = searchOption == CONSTRAINED ? exp( inverse_infty_transform( pars[counter++], log( other.min_factorIntMat(i,j) ), log( other.max_factorIntMat(i,j) ) ) ) : exp( pars[counter++] );
                factorIntMat( i, j ) = interaction;
            }
            else factorIntMat( i, j ) = ExprPar::default_interaction;
        }
    }
    for ( int i = 0; i < _nFactors; i++ )
    {
        for ( int j = i + 1; j < _nFactors; j++ )
        {
            factorIntMat( i, j ) = factorIntMat( j, i );
        }
    }

    // set the transcriptional effects
    for ( int i = 0; i < _nFactors; i++ )
    {
        if ( actIndicators[i] )
        {
            double effect = searchOption == CONSTRAINED ? exp( inverse_infty_transform( pars[counter++], log( other.min_effects_Thermo[i] ), log( other.max_effects_Thermo[i] ) ) ) : exp( pars[counter++] );
            txpEffects.push_back( effect );
        }
        else
        {
            txpEffects.push_back( ExprPar::default_effect_Thermo );
        }
    }

    // set the repression effects
    if ( modelOption == CHRMOD_UNLIMITED || modelOption == DIRECT )
    {
        for ( int i = 0; i < _nFactors; i++ )
        {
            if ( repIndicators[i] )
            {
                double repression = searchOption == CONSTRAINED ? exp( inverse_infty_transform( pars[counter++], log( other.min_repressions[i] ), log( other.max_repressions[i] ) ) ) : exp( pars[counter++] );
                repEffects.push_back( repression );
            }
            else
            {
                repEffects.push_back( ExprPar::default_repression );
            }
        }
    }
    else
    {
        for ( int i = 0; i < _nFactors; i++ ) repEffects.push_back( ExprPar::default_repression );
    }

    // set the basal transcription
    double basal = searchOption == CONSTRAINED ? exp( inverse_infty_transform( pars[counter++], log( other.min_basals_Thermo[0] ), log( other.max_basals_Thermo[0] ) ) ) : exp( pars[counter++] );
            basalTxps.push_back( basal );

    for( int i = 0; i < _nFactors; i++ )
    {
        double energyThrFactor_val = searchOption == CONSTRAINED ? exp ( inverse_infty_transform( pars[ counter++ ], log( other.min_energyThrFactors_[i] ), log( other.max_energyThrFactors_[i] ) ) ) : exp ( pars[ counter++ ] );
        energyThrFactors.push_back( energyThrFactor_val );
    }
    //create constraints

    //min_factorIntMat.setDimensions( _nFactors, _nFactors );
    //max_factorIntMat.setDimensions( _nFactors, _nFactors );
    min_factorIntMat = other.min_factorIntMat; 
    max_factorIntMat = other.max_factorIntMat; 
    
    min_weights = other.min_weights; 
    max_weights = other.max_weights; 
    min_effects_Thermo = other.min_effects_Thermo; 
    max_effects_Thermo = other.max_effects_Thermo; 
    min_repressions = other.min_repressions;
    max_repressions = other.max_repressions; 
    min_basals_Thermo = other.min_basals_Thermo; 
    max_basals_Thermo = other.max_basals_Thermo; 
    min_energyThrFactors_ = other.min_energyThrFactors_; 
    max_energyThrFactors_ = other.max_energyThrFactors_; 
}


void ExprPar::getFreePars( vector< double >& pars, const IntMatrix& coopMat, const vector< bool >& actIndicators, const vector< bool >& repIndicators ) const
{
    assert( coopMat.isSquare() && coopMat.nRows() == nFactors() );
    assert( actIndicators.size() == nFactors() && repIndicators.size() == nFactors() );
    pars.clear();

    // write maxBindingWts
    if ( estBindingOption )
    {
        for ( int i = 0; i < nFactors(); i++ )
        {
            double weight = searchOption == CONSTRAINED ? infty_transform( log( maxBindingWts[ i ] ), log( min_weights[i] ), log( max_weights[i] ) ) : log( maxBindingWts[i] );
            pars.push_back( weight );
        }
    }

    // write the interaction matrix
        for ( int i = 0; i < nFactors(); i++ )
        {
            for ( int j = 0; j <= i; j++ )
            {
                if ( coopMat( i, j ) )
                {
                    double interaction = searchOption == CONSTRAINED ? infty_transform( log( factorIntMat( i, j ) ), log(min_factorIntMat( i, j ) ), log(max_factorIntMat( i, j ) ) ) : log( factorIntMat( i, j ) );
                    pars.push_back( interaction );
                }
            }
        }
    

    // write the transcriptional effects
    for ( int i = 0; i < nFactors(); i++ )
    {

            if ( actIndicators[i] )
            {
                double effect = searchOption == CONSTRAINED ? infty_transform( log( txpEffects[i] ), log( min_effects_Thermo[i] ), log( max_effects_Thermo[i] ) ) : log( txpEffects[i] );
                pars.push_back( effect );
            }
			
    }

    // write the repression effects
    if ( modelOption == CHRMOD_UNLIMITED || modelOption == DIRECT )
    {
        for ( int i = 0; i < nFactors(); i++ )
        {
            if ( repIndicators[i] )
            {
                double repression = searchOption == CONSTRAINED ? infty_transform( log( repEffects[i] ), log( min_repressions[i] ), log( max_repressions[i] ) ) : log( repEffects[i] );
                pars.push_back( repression );
            }
        }
    }

    for( int i = 0; i < basalTxps.size(); i++ )
    {
            double basal = searchOption == CONSTRAINED ? infty_transform( log( basalTxps[ i ] ), log( min_basals_Thermo[i] ), log( max_basals_Thermo[i] ) ) : log( basalTxps[ i ] );
            pars.push_back( basal );
    }

    for( int i = 0; i < energyThrFactors.size(); i++ )
    {
        double energyThrFactor_val = searchOption == CONSTRAINED ? infty_transform( log( energyThrFactors[ i ]),log(min_energyThrFactors_[i]), log(max_energyThrFactors_[i]) ) : log( energyThrFactors[ i ] );
        pars.push_back( energyThrFactor_val );
    }
}


void ExprPar::print( ostream& os, const vector< string >& motifNames, const IntMatrix& coopMat ) const
{
    os.setf( ios::fixed );
    os.precision( 5 );

    // print the factor information
    for ( int i = 0; i < nFactors(); i++ )
    {
        os << motifNames[i] << "\t" << maxBindingWts[i] << "\t" << txpEffects[i];
        if ( modelOption == CHRMOD_UNLIMITED || modelOption == DIRECT ) os << "\t" << repEffects[i];
        os << endl;
    }

    // print the basal transcription
    os << "basal_transcription = " << basalTxps[ 0 ] << endl;
    for( int _i = 1; _i < basalTxps.size(); _i++ )
    {
        os << basalTxps[ _i ] << endl;
    }

    // print the cooperative interactions
    for ( int i = 0; i < nFactors(); i++ )
    {
        for ( int j = 0; j <= i; j++ )
        {
            if ( coopMat( i, j ) ) os << motifNames[i] << "\t" << motifNames[j] << "\t" << factorIntMat( i, j ) << endl;
        }
    }

    for( int i = 0; i < energyThrFactors.size(); i++ )
    {
        cout << energyThrFactors[ i ] << "\t";
    }
    cout << endl;

}


int ExprPar::load( const string& file, const int num_of_coop_pairs )
{
    // open the file
    ifstream fin( file.c_str() );
    if ( !fin ){ cerr << "Cannot open parameter file " << file << endl; exit( 1 ); }

    // read the factor information
    vector< string > motifNames( nFactors() );
    for ( int i = 0; i < nFactors(); i++ )
    {
        fin >> motifNames[i] >> maxBindingWts[i] >> txpEffects[i];
        if ( modelOption == CHRMOD_UNLIMITED || modelOption == DIRECT ) fin >> repEffects[i];
    }

    // factor name to index mapping
    map< string, int > factorIdxMap;
    for ( int i = 0; i < nFactors(); i++ )
    {
        factorIdxMap[motifNames[i]] = i;
    }

    // read the basal transcription
    string symbol, eqSign, value;
    fin >> symbol >> eqSign >> value;
    if ( symbol != "basal_transcription" || eqSign != "=" ) return RET_ERROR;
    double basalTxp_val = atof( value.c_str() );
    basalTxps[ 0 ] =  basalTxp_val ;

    // read the cooperative interactions
    string factor1, factor2;
    double coopVal;
    for( int i = 0; i < num_of_coop_pairs; i++ )
    {
        fin >> factor1 >> factor2 >> coopVal;
        if( !factorIdxMap.count( factor1 ) || !factorIdxMap.count( factor2 ) ) return RET_ERROR;
        int idx1 = factorIdxMap[factor1];
        int idx2 = factorIdxMap[factor2];
        factorIntMat( idx1, idx2 ) = coopVal;
        factorIntMat( idx2, idx1 ) = coopVal;
        //cout << factor1 << "\t" << factor2 << "\t" << idx1 << "\t" << idx2 << endl;
    }
    double factor_thr_val;
    energyThrFactors.clear();
    while( fin >> factor_thr_val )
    {
        energyThrFactors.push_back( factor_thr_val );
    }

    if( ExprPar::is_bounded_search ){
    	cout << "Updating ranges w.r.t. loaded parameters" << endl;
    	int _nFactors = nFactors();
    	for(int i = 0; i < _nFactors; i++){
		for(int j = 0; j < _nFactors; j++){
			min_factorIntMat(i,j ) = factorIntMat(i,j) / 2;
			max_factorIntMat(i,j ) = factorIntMat(i,j) * 2;
		}
        	min_weights[ i ] = maxBindingWts[ i ] / 2;
        	max_weights[ i ] = maxBindingWts[ i ] * 2;
		min_effects_Thermo[ i ] = txpEffects[ i ] / 2;
		max_effects_Thermo[ i ] = txpEffects[ i ] * 2;
		min_repressions[ i ] = repEffects[ i ] / 2;
		max_repressions[ i ] = repEffects[ i ] * 2;
		min_energyThrFactors_[ i ] = energyThrFactors[ i ] / 2;
		max_energyThrFactors_[ i ] = ((energyThrFactors[ i ] * 2) > 1) ? 0.99 : energyThrFactors[ i ] * 2;
	}
	min_basals_Thermo[ 0 ] = basalTxps[ 0 ] / 2;
	max_basals_Thermo[ 0 ] = basalTxps[ 0 ] * 2;
    }
    return 0;
}


void ExprPar::adjust( const IntMatrix& coopMat  )
{
    // adjust binding paramters
    for ( int i = 0; i < nFactors(); i++ )
    {
        if ( maxBindingWts[i] < min_weights[i] * ( 1.0 + ExprPar::delta ) ) { maxBindingWts[i] *= 2.0;}
        if ( maxBindingWts[i] > max_weights[i] * ( 1.0 - ExprPar::delta ) ) { maxBindingWts[i] /= 2.0;}
    }

    // adjust the interaction matrix
    for ( int i = 0; i < nFactors(); i++ )
    {
        for ( int j = 0; j <= i; j++ )
        {
            if ( coopMat( i, j ) &&   factorIntMat( i, j ) < min_factorIntMat(i,j) * ( 1.0 + ExprPar::delta ) )
            {
                factorIntMat( i, j ) *= 2.0;
                factorIntMat( j, i ) = factorIntMat( i, j );
            }
            if ( coopMat( i, j ) &&  factorIntMat( i, j ) > max_factorIntMat(i,j) * ( 1.0 - ExprPar::delta ) )
            {
                factorIntMat( i, j ) /= 2.0;
                factorIntMat( j, i ) = factorIntMat( i, j );
            }
        }
    }
    // adjust transcriptional effects
    for ( int i = 0; i < nFactors(); i++ )
    {
            if ( txpEffects[i] < min_effects_Thermo[i] * ( 1.0 + ExprPar::delta ) ) { txpEffects[i] *= 2.0;}
            if ( txpEffects[i] > max_effects_Thermo[i] * ( 1.0 - ExprPar::delta ) ) { txpEffects[i] /= 2.0;}
    }

    // adjust the repression effects
    if ( modelOption == CHRMOD_UNLIMITED || modelOption == DIRECT )
    {
        for ( int i = 0; i < nFactors(); i++ )
        {
            if ( repEffects[i] < min_repressions[i] * ( 1.0 + ExprPar::delta ) )
            {
                if( repEffects[ i ] > 0 ) repEffects[i] *= 2.0;
                else repEffects[ i ] = min_repressions[i] * ( 1 + 2 * ExprPar::delta );
            }
            if ( repEffects[i] > max_repressions[i] * ( 1.0 - ExprPar::delta ) ) {repEffects[i] /= 2.0;}
        }
    }

    // adjust the basl transcription
    for( int _i = 0; _i < basalTxps.size(); _i ++ )
    {
            if ( basalTxps[ _i ] < min_basals_Thermo[_i] * ( 1.0 + ExprPar::delta ) ) basalTxps[ _i ] *= 2.0;
            if ( basalTxps[ _i ] > max_basals_Thermo[_i] * ( 1.0 - ExprPar::delta ) ) basalTxps[ _i ] /= 2.0;
    }

    //adjust the energyThrFactors
    for( int i = 0; i < nFactors(); i++ )
    {
        if( energyThrFactors[ i ] < min_energyThrFactors_[i] * ( 1.0 + ExprPar::delta ) ) energyThrFactors[ i ] *= 2.0;
        if( energyThrFactors[ i ] > max_energyThrFactors_[i] * ( 1.0 - ExprPar::delta ) ) energyThrFactors[ i ] /= 2.0;
    }
}


ModelType ExprPar::modelOption = CHRMOD_UNLIMITED;
ModelType ExprFunc::modelOption = CHRMOD_UNLIMITED;
SearchType ExprPar::searchOption = UNCONSTRAINED;

bool ExprPar::is_bounded_search = false;
int ExprPar::estBindingOption = 1;                // 1. estimate binding parameters; 0. not estimate binding parameters

double ExprPar::default_weight = 1.0;
double ExprPar::default_interaction = 1.0;
double ExprPar::default_effect_Thermo = 1.0;
double ExprPar::default_repression = 1.0E-2;
double ExprPar::default_basal_Thermo = 0.005;

double ExprPar::min_weight = 1E-2;
double ExprPar::max_weight = 1E4;

double ExprPar::min_interaction = 1E-2;
double ExprPar::max_interaction = 1E2;
// double ExprPar::min_effect_Direct = 0.01;

double ExprPar::min_effect_Thermo = 0.99;
double ExprPar::max_effect_Thermo = 10;

double ExprPar::min_repression = 1E-10;
double ExprPar::max_repression = 1;

double ExprPar::min_basal_Thermo = 1E-3;
double ExprPar::max_basal_Thermo = 1E-2;

double ExprPar::delta = 1E-10;
double ExprPar::default_window_weight = 1;
double ExprPar::min_window_weight = 0.01;
double ExprPar::max_window_weight = 2;
double ExprPar::min_energyThrFactors = 0.1;
double ExprPar::max_energyThrFactors = 0.99;

double ExprPar::default_energyThrFactors = 0.9;

bool ExprPar::one_qbtm_per_crm = false;
bool ExprFunc::one_qbtm_per_crm = false;

ExprFunc::ExprFunc( const vector< Motif >& _motifs, const FactorIntFunc* _intFunc, const vector< bool >& _actIndicators, int _maxContact, const vector< bool >& _repIndicators, const IntMatrix& _repressionMat, double _repressionDistThr, const ExprPar& _par ) : motifs( _motifs ), intFunc( _intFunc ), actIndicators( _actIndicators ), maxContact( _maxContact ), repIndicators( _repIndicators ), repressionMat( _repressionMat ), repressionDistThr( _repressionDistThr ), par( _par )
{
    int nFactors = par.nFactors();
    assert( motifs.size() == nFactors );
    assert( actIndicators.size() == nFactors );
    assert( repIndicators.size() == nFactors );
    assert( repressionMat.isSquare() && repressionMat.nRows() == nFactors );
    assert( maxContact >= 0 );
}


double ExprFunc::predictExpr( const SiteVec& _sites, int length, const vector< double >& factorConcs, int seq_num )
{
    bindingWts.clear(); boundaries.clear();

    if( !one_qbtm_per_crm )
        seq_num = 0;
    // store the sequence
    int n = _sites.size();
    sites = _sites;
    sites.insert( sites.begin(), Site() );        // start with a pseudo-site at position 0
    boundaries.push_back( 0 );
    double range = max( intFunc->getMaxDist(), repressionDistThr );
    for ( int i = 1; i <= n; i++ )
    {
        int j;
        for ( j = i - 1; j >= 1; j-- )
        {
            if ( ( sites[i].start - sites[j].start ) > range ) break;
        }
        int boundary = j;
        boundaries.push_back( boundary );
    }

    // compute the Boltzman weights of binding for all sites
    bindingWts.push_back( 1.0 );
    for ( int i = 1; i <= n; i++ )
    {
        bindingWts.push_back( par.maxBindingWts[ sites[i].factorIdx ] * factorConcs[sites[i].factorIdx] * sites[i].prior_probability * sites[i].wtRatio );
        double samee = par.maxBindingWts[sites[i].factorIdx]*factorConcs[sites[i].factorIdx]*sites[i].prior_probability*sites[i].wtRatio;
        if(samee != samee)
        {
            cout << "DEBUG: samee for " << i << "\t" << sites[i].factorIdx << "\t" <<  par.maxBindingWts[sites[i].factorIdx] <<"\t" << factorConcs[sites[i].factorIdx] <<"\t" << sites[i].prior_probability <<"\t" << sites[i].wtRatio << endl;
            exit(1);
        }
    }


    // Thermodynamic models: Direct, Quenching, ChrMod_Unlimited and ChrMod_Limited
    // compute the partition functions
    double Z_off = compPartFuncOff();
    double Z_on = compPartFuncOn();

    double efficiency = Z_on / Z_off;

    double promoterOcc = efficiency * par.basalTxps[ seq_num ] / ( 1.0 + efficiency * par.basalTxps[ seq_num ] );
    return promoterOcc;
}



double ExprFunc::compPartFuncOff() const
{
    if ( modelOption == CHRMOD_UNLIMITED ) return compPartFuncOffChrMod();

    int n = sites.size() - 1;
    // initialization
    vector< double > Z( n + 1 );
    Z[0] = 1.0;
    vector< double > Zt( n + 1 );
    Zt[0] = 1.0;

    // recurrence
    for ( int i = 1; i <= n; i++ )
    {
        double sum = Zt[boundaries[i]];
        for ( int j = boundaries[i] + 1; j < i; j++ )
        {
            if ( siteOverlap( sites[ i ], sites[ j ], motifs ) ) continue;
            sum += compFactorInt( sites[ i ], sites[ j ] ) * Z[ j ];
        }

        Z[i] = bindingWts[ i ] * sum;
        Zt[i] = Z[i] + Zt[i - 1];
    }

    return Zt[n];
}

double ExprFunc::compPartFuncOffChrMod() const
{
    int n = sites.size()- 1;

    // initialization
    vector< double > Z0( n + 1 );
    Z0[0] = 1.0;
    vector< double > Z1( n + 1 );
    Z1[0] = 1.0;
    vector< double > Zt( n + 1 );
    Zt[0] = 1.0;

    // recurrence
    for ( int i = 1; i <= n; i++ )
    {
        double sum = Zt[boundaries[i]];
        double sum0 = sum, sum1 = sum;
        for ( int j = boundaries[i] + 1; j < i; j++ )
        {
            if ( siteOverlap( sites[ i ], sites[ j ], motifs ) ) continue;
            double dist = sites[i].start - sites[j].start;

            // sum for Z0
            sum0 += compFactorInt( sites[i], sites[j] ) * Z0[j];
            if ( dist > repressionDistThr ) sum0 += Z1[j];

            // sum for Z1
            if ( repIndicators[ sites[i].factorIdx ] )
            {
                sum1 += compFactorInt( sites[i], sites[j] ) * Z1[j];
                if ( dist > repressionDistThr ) sum1 += Z0[j];
            }
        }
        Z0[i] = bindingWts[i] * sum0;
        if ( repIndicators[ sites[i].factorIdx ] ) Z1[i] = bindingWts[i] * par.repEffects[ sites[i].factorIdx ] * sum1;
        else Z1[i] = 0;
        Zt[i] = Z0[i] + Z1[i] + Zt[i - 1];
    }

    // the partition function
    return Zt[n];
}


double ExprFunc::compPartFuncOn() const
{
    if ( modelOption == DIRECT ) return compPartFuncOnDirect();
    if ( modelOption == CHRMOD_UNLIMITED) return compPartFuncOnChrMod_Unlimited();
}


double ExprFunc::compPartFuncOnDirect() const
{
    int n = sites.size() - 1;

    // initialization
    vector< double > Z( n + 1 );
    Z[0] = 1.0;
    vector< double > Zt( n + 1 );
    Zt[0] = 1.0;

    // recurrence
    for ( int i = 1; i <= n; i++ )
    {
        double sum = Zt[boundaries[i]];
        for ( int j = boundaries[i] + 1; j < i; j++ )
        {
            if ( siteOverlap( sites[ i ], sites[ j ], motifs ) ) continue;
            sum += compFactorInt( sites[ i ], sites[ j ] ) * Z[ j ];
        }
        //Z[i] = bindingWts[ i ] * par.txpEffects[ sites[i].factorIdx ] * sum;
        if( actIndicators[ sites[ i ].factorIdx ] )
        {
            Z[ i ] = bindingWts[ i ] * par.txpEffects[ sites[ i ].factorIdx ] * sum;
        }
        if( repIndicators[ sites[ i ].factorIdx ] )
        {
            Z[ i ] = bindingWts[ i ] * par.repEffects[ sites[ i ].factorIdx ] * sum;
        }
        Zt[i] = Z[i] + Zt[i - 1];
    }

    return Zt[n];
}

double ExprFunc::compPartFuncOnChrMod_Unlimited() const
{
    int n = sites.size()- 1;

    // initialization
    vector< double > Z0( n + 1 );
    Z0[0] = 1.0;
    vector< double > Z1( n + 1 );
    Z1[0] = 1.0;
    vector< double > Zt( n + 1 );
    Zt[0] = 1.0;

    // recurrence
    for ( int i = 1; i <= n; i++ )
    {
        double sum = Zt[boundaries[i]];
        double sum0 = sum, sum1 = sum;
        for ( int j = boundaries[i] + 1; j < i; j++ )
        {
            double dist = sites[i].start - sites[j].start;
            if ( siteOverlap( sites[ i ], sites[ j ], motifs ) ) continue;

            // sum for Z0
            sum0 += compFactorInt( sites[i], sites[j] ) * Z0[j];
            if ( dist > repressionDistThr ) sum0 += Z1[j];

            // sum for Z1
            if ( repIndicators[ sites[i].factorIdx ] )
            {
                sum1 += compFactorInt( sites[i], sites[j] ) * Z1[j];
                if ( dist > repressionDistThr ) sum1 += Z0[j];
            }
        }
        Z0[i] = bindingWts[i] * par.txpEffects[ sites[i].factorIdx ] * sum0;
        if ( repIndicators[ sites[i].factorIdx ] ) Z1[i] = bindingWts[i] * par.repEffects[ sites[i].factorIdx ] * sum1;
        else Z1[i] = 0;
        Zt[i] = Z0[i] + Z1[i] + Zt[i - 1];
    }

    // the partition function
    return Zt[n];
}

double ExprFunc::compFactorInt( const Site& a, const Site& b ) const
{
    // 	assert( !siteOverlap( a, b, motifs ) );
    double maxInt = par.factorIntMat( a.factorIdx, b.factorIdx );
    double dist = abs( a.start - b.start );
    bool orientation = ( a.strand == b.strand );
    return intFunc->compFactorInt( maxInt, dist, orientation );
}


bool ExprFunc::testRepression( const Site& a, const Site& b ) const
{
    // 	assert( !siteOverlap( a, b, motifs ) );

    double dist = abs( a.start - b.start );
    return repressionMat( a.factorIdx, b.factorIdx ) && ( dist <= repressionDistThr );
}


ExprPredictor::ExprPredictor( const vector <Sequence>& _seqs, /*const vector< int >& _seqLengths,*/ const Matrix& _exprData, const vector < vector < vector < double > > >& _stripe_expr_data, const vector< Motif >& _motifs, const Matrix& _factorExprData, const FactorIntFunc* _intFunc, const IntMatrix& _coopMat, const vector< bool >& _actIndicators, const vector< bool >& _repIndicators, const IntMatrix& _repressionMat, double _repressionDistThr, const vector < bool >& _indicator_bool, const vector <string>& _motifNames ) : seqs(_seqs), /*seqLengths( _seqLengths ),*/ exprData( _exprData ), stripe_expr_data(_stripe_expr_data), motifs( _motifs ), factorExprData( _factorExprData ), intFunc( _intFunc ), coopMat( _coopMat ), actIndicators( _actIndicators ), repIndicators( _repIndicators ), repressionMat( _repressionMat ), repressionDistThr( _repressionDistThr ), indicator_bool ( _indicator_bool ), motifNames ( _motifNames )
{
    assert( exprData.nRows() == nSeqs() );
    assert( factorExprData.nRows() == nFactors() && factorExprData.nCols() == nConds() );
    assert( coopMat.isSquare() && coopMat.isSymmetric() && coopMat.nRows() == nFactors() );
    assert( actIndicators.size() == nFactors() );
    assert( repIndicators.size() == nFactors() );
    assert( repressionMat.isSquare() && repressionMat.nRows() == nFactors() );
    assert( repressionDistThr >= 0 );

    // set the model option for ExprPar and ExprFunc
    ExprPar::modelOption = modelOption;
    ExprFunc::modelOption = modelOption;

    // set the values of the parameter range according to the model option
    // set the option of parameter estimation
    ExprPar::estBindingOption = estBindingOption;
}


double ExprPredictor::objFunc( const ExprPar& par )
{
	if( !testPar( par ) ){
		cout << "testPar failed" << endl;
		return DBL_MAX;
	}
    	if ( objOption == SSE ) return compRMSE( par );
    	if ( objOption == CORR ) return -compAvgCorr( par );
	if ( objOption == PGP ) return -compPGP( par );
}


int ExprPredictor::train( const ExprPar& par_init )
{
    cout << "Entering into train()" << endl;
    printPar( par_init );
    par_model = par_init;
   //if ( nAlternations > 0 && ExprPar::searchOption == CONSTRAINED ) par_model.adjust( coopMat );
    obj_model = objFunc( par_model );

    if ( nAlternations == 0 ) return 0;
    
    // alternate between two different methods
    ExprPar par_result;
    double obj_result;

	double improvement_thr = 1E-4;
	double cur_estimate = DBL_MAX;

    for ( int i = 0; i < nAlternations; i++ ) {
	simplex_minimize( par_result, obj_result );
        if( obj_result != obj_result ){
		break;
	}
	par_model = par_result; 
	obj_model = obj_result;
        
	gradient_minimize( par_result, obj_result );
        if( obj_result != obj_result ){
		break;
	}
        par_model = par_result;
	obj_model = obj_result;
	
	double improvement = cur_estimate - obj_model;
	if( improvement > improvement_thr ){
		cur_estimate = obj_model;
	}
	else{
		break;
	}
    }
	
    return 0;	
}

/*
*/

int ExprPredictor::predict( const SiteVec& targetSites_, int targetSeqLength, vector< double >& targetExprs, int seq_num ) const
{
    targetExprs.clear();

    // create site representation of the target sequence
    SiteVec targetSites;
    SeqAnnotator ann( motifs, par_model.energyThrFactors );
    ann.annot( seqs[ seq_num ], targetSites );

    // predict the expression
    ExprFunc* func = createExprFunc( par_model );
    for ( int j = 0; j < nConds(); j++ )
    {
        vector< double > concs = factorExprData.getCol( j );
        double predicted = func->predictExpr( targetSites, targetSeqLength, concs, seq_num );
        targetExprs.push_back( predicted );
    }

    delete func;
    return 0;
}


ModelType ExprPredictor::modelOption = DIRECT;
int ExprPredictor::estBindingOption = 1;          // 1. estimate binding parameters; 0. not estimate binding parameters
ObjType ExprPredictor::objOption = SSE;

int ExprPredictor::nAlternations = 4;
int ExprPredictor::nRandStarts = 5;
double ExprPredictor::min_delta_f_SSE = 1.0E-8;
double ExprPredictor::min_delta_f_Corr = 1.0E-8;
double ExprPredictor::min_delta_f_PGP = 1.0E-8;
int ExprPredictor::nSimplexIters = 200;
int ExprPredictor::window_train_iter = 100;
int ExprPredictor::nGradientIters = 50;
bool ExprPredictor::one_qbtm_per_crm = false;

bool ExprPredictor::testPar( const ExprPar& par ) const
{
    // test binding weights
    if ( estBindingOption )
    {
        for ( int i = 0; i < nFactors(); i++ )
        {
		if ( par.maxBindingWts[i] != par.maxBindingWts[i] )
			return false;
		if ( par.maxBindingWts[i] < par.min_weights[i] * ( 1.0 + ExprPar::delta ) || par.maxBindingWts[i] > par.max_weights[i] * ( 1.0 - ExprPar::delta ) )
                	return false;
        }
    }

    // test the interaction matrix

        for ( int i = 0; i < nFactors(); i++ )
        {
            for ( int j = 0; j <= i; j++ )
            {
            	if ( par.factorIntMat( i, j ) !=  par.factorIntMat( i, j ) )
			return false;
		if ( par.factorIntMat( i, j ) < par.min_factorIntMat(i,j) * ( 1.0 + ExprPar::delta ) || par.factorIntMat( i, j ) > par.max_factorIntMat(i,j) * ( 1.0 - ExprPar::delta ) )
                	return false;
            }
        }

    // test the transcriptional effects
    for ( int i = 0; i < nFactors(); i++ )
    {
        if ( actIndicators[i] )
            {
	    	if ( par.txpEffects[i] != par.txpEffects[i] )
			return false;
                if ( par.txpEffects[i] < par.min_effects_Thermo[i] * ( 1.0 + ExprPar::delta ) || par.txpEffects[i] > par.max_effects_Thermo[i] * ( 1.0 - ExprPar::delta ) )
                    	return false;
            }
    }

    // test the repression effects
    if ( modelOption == CHRMOD_UNLIMITED || modelOption == DIRECT )
    {
        for ( int i = 0; i < nFactors(); i++ )
        {
            if ( repIndicators[i] )
            {
	    	if ( par.repEffects[i] != par.repEffects[i] )
			return false;
                if ( par.repEffects[i] < par.min_repressions[i] * ( 1.0 + ExprPar::delta ) || par.repEffects[i] > par.max_repressions[i] * ( 1.0 - ExprPar::delta ) )
                    	return false;
            }
        }
    }
    // test the basal transcription
    for( int _i = 0; _i < par.basalTxps.size(); _i++ )
    {
    	if ( par.basalTxps[ _i ] != par.basalTxps[ _i ] ) 
		return false;
	if ( par.basalTxps[ _i ] < par.min_basals_Thermo[_i] * ( 1.0 + ExprPar::delta ) || par.basalTxps[ _i ] > par.max_basals_Thermo[_i] * ( 1.0 - ExprPar::delta ) )
        	return false;
    }
    //test the energyThrFactors
    for( int i = 0; i < nFactors(); i++ )
    {
    	if( par.energyThrFactors[ i ] != par.energyThrFactors[ i ] )
		return false;
        if( par.energyThrFactors[ i ] < par.min_energyThrFactors_[i] * ( 1.0 + ExprPar::delta ) ) return false;
        if( par.energyThrFactors[ i ] > par.max_energyThrFactors_[i] * ( 1.0 - ExprPar::delta ) ) return false;
    }
    return true;
}


void ExprPredictor::printPar( const ExprPar& par ) const
{
    cout.setf( ios::fixed );
    cout.precision( 5 );
    //     cout.width( 8 );

    // print binding weights
    if ( estBindingOption )
    {
    	cout << "Binding weights:\t";
        for ( int i = 0; i < nFactors(); i++ )
        {
            cout << par.maxBindingWts[i] << "\t";
        }
	cout << endl;
    }

    // print the interaction matrix
    cout << "Interactions:\t";
    for ( int i = 0; i < nFactors(); i++ )
    {
        for ( int j = 0; j <= i; j++ )
        {
            if ( coopMat( i, j ) ) cout << par.factorIntMat( i, j ) << "\t";
        }
    }
    cout << endl;

    // print the transcriptional effects
    cout << "Txp effects:\t";
    for ( int i = 0; i < nFactors(); i++ )
    {
		if ( actIndicators[i] ) cout << par.txpEffects[i] << "\t";
    }

    // print the repression effects
    if ( modelOption == CHRMOD_UNLIMITED || modelOption == DIRECT )
    {
        for ( int i = 0; i < nFactors(); i++ )
        {
            if ( repIndicators[i] ) cout << par.repEffects[i] << "\t";
        }
    }
	cout << endl;
    // print the basal transcriptions
    cout << "Basal txp:\t";
    for( int _i = 0; _i < par.basalTxps.size(); _i ++ )
    {
        cout << par.basalTxps[ _i ] << "\t";
    }
    cout << endl;
	cout << "TF energy thresholds:\t";
    for( int _i = 0; _i < par.energyThrFactors.size(); _i++ )
    {
        cout << par.energyThrFactors[ _i ] << "\t";
    }
    cout << endl;
}


ExprFunc* ExprPredictor::createExprFunc( const ExprPar& par ) const
{
    return new ExprFunc( motifs, intFunc, actIndicators, maxContact, repIndicators, repressionMat, repressionDistThr, par );
}

double ExprPredictor::compRMSE( const ExprPar& par ) 
{
    // error of each sequence
    double squaredErr = 0;
    for ( int i = 0; i < nSeqs(); i++ ) {
        vector< double > predictedExprs (nConds(), 0);
        vector< double > observedExprs;
	compute_solution(predictedExprs, par, i);
        for ( int j = 0; j < nConds(); j++ ) {
			double observed = exprData( i, j );
			observedExprs.push_back( observed );
		}
        double beta; 
        squaredErr += least_square( predictedExprs, observedExprs, beta );
    }	

    double rmse = sqrt( squaredErr / ( nSeqs() * nConds() ) );//use this line if least_square() is used 
    return rmse;
}

double ExprPredictor::compAvgCorr( const ExprPar& par )
{
    // Pearson correlation of each sequence
    double totalSim = 0;
    for ( int i = 0; i < nSeqs(); i++ )
    {
        vector< double > predictedExprs (nConds(), 0);
        vector< double > observedExprs;
	compute_solution(predictedExprs, par, i);
        for ( int j = 0; j < nConds(); j++ )
        {
            double observed = exprData( i, j );
            observedExprs.push_back( observed );
        }
        totalSim += corr( predictedExprs, observedExprs );
    }
    return totalSim / nSeqs();
}

double ExprPredictor::compPGP( const ExprPar& par )
{
    double totalSim = 0;
    for ( int i = 0; i < nSeqs(); i++ )
    {
        vector< double > predictedExprs (nConds(), 0);
        vector< double > observedExprs;
	compute_solution(predictedExprs, par, i);
        for ( int j = 0; j < nConds(); j++ )
        {
            double observed = exprData( i, j );
            observedExprs.push_back( observed );
        }
        double beta;
        totalSim += pgp( predictedExprs, observedExprs, beta );
    }
    return totalSim / nSeqs();
}

int ExprPredictor::max_window_len = 800;//class member
int ExprPredictor::min_window_len = 500;//class memeber
int ExprPredictor::window_len_inc = 250;//class member
int ExprPredictor::window_shift = 100;//class member
int ExprPredictor::n_window_per_stripe = 2;//class member

void ExprPredictor::add_expr( int i, int first, int last, vector < double >& added_expr )
{
	//added_expr.clear();
	for( int j = first; j <= last; j++ ){
		for( int k = 0; k < nConds(); k++ ){
			added_expr[k] += stripe_expr_data[i][j][k];
		}
	}
}

void ExprPredictor::compute_readout_of_window(const SiteVec& seqSites, const ExprPar& par, vector < double > & predictedExprs, int seqLengths, int seq_index )
{
    ExprFunc* func = createExprFunc( par );
    predictedExprs.clear();
    for ( int j = 0; j < nConds(); j++ )
    {
        vector< double > concs = factorExprData.getCol( j );
        double predicted = func->predictExpr( seqSites, seqLengths, concs, seq_index );
        // predicted expression for the i-th sequence at the j-th condition
        predictedExprs.push_back( predicted );
    }
}

void ExprPredictor::compute_solution( vector < double >& final_predicted_exprs, const ExprPar& par, int seq_index )
{
	cout << "Computing solution corresponding to parameters: " << endl;
	printPar( par );
    ExprFunc* func = createExprFunc( par );
    SiteVec seqSites;
    int seqLengths;
    SeqAnnotator ann( motifs, par.energyThrFactors );
    int i = seq_index;
    cur_gene_index = seq_index;
    ann.annot( seqs[ i ], seqSites );
    seqLengths = seqs[i].size();
		
    //step 1: compute best candidates
    vector < vector < int > > best_window_loc(n_stripe(i), vector < int >(n_window_per_stripe,-1));	
    vector < vector < int > > best_window_len(n_stripe(i), vector < int >(n_window_per_stripe,-1));	
    vector < vector < double > > best_window_score(n_stripe(i), vector < double >(n_window_per_stripe,DBL_MAX));
    vector < vector < vector < double > > > best_window_expr(n_stripe(i), vector < vector < double > > (n_window_per_stripe, vector < double >(nConds(), 0)));
	
    for( int window_len = min_window_len; window_len <= max_window_len; window_len += window_len_inc ){
        for( int start = 0; start <= seqs[i].size() - window_len; start += window_shift ){
		SiteVec cur_window_sites;//vector of sites in the current window
		//construction of cur_window_sites. note: the sites are already annotated at the beginning of the "i-indexed" loop
		//cout << "Trying window of len: " << window_len << " starting at: " << start << endl;
		int start_index = 0;
		for( int j = 0; j < seqSites.size(); j++ ){
			if( seqSites[j].start >= start ){
				start_index = j;
				break;
			}
		}
		for( int j = start_index; j < seqSites.size(); j++ ){
			int _factor_id = seqSites[j].factorIdx;
			if( seqSites[j].start + motifs[_factor_id].length() <= start + window_len ){
				cur_window_sites.push_back( seqSites[j] );
			}
			else{
				break;
			}
		}
		//predict the readout of current_window 
		vector < double > predicted_expr;
		compute_readout_of_window( cur_window_sites, par, predicted_expr, seqLengths, i );
		//important note: seqLengths is no longer used for any purpose.
		//cout << "Predicted expression: " << endl;
		//cout << predicted_expr << endl;
		//for each stripe of the gene, check if the current_window is a candidate CRM of that stripe
		for( int j = 0; j < n_stripe( i ); j++ ){
			vector < double > stripe_expr = stripe_expr_data[i][j];
			//cout << "Comparing against stripe: " << j << endl;
			//cout << stripe_expr << endl;
			double window_score, beta;
			if(objOption == SSE){
				double sse_score = least_square( predicted_expr, stripe_expr, beta );
				//cout << "beta for SSE = " << beta << endl;
				window_score = sqrt(sse_score/nConds());
				//cout << "score for SSE = " << window_score << endl;
				for(int _temp_i = 0; _temp_i < nConds(); _temp_i ++){
					predicted_expr[_temp_i] *= beta;
				}
			}
			else if(objOption == CORR){
				window_score = -corr( predicted_expr, stripe_expr );
				//cout << "score for Corr = " << window_score << endl;
				least_square( predicted_expr, stripe_expr, beta );
				for(int _temp_i = 0; _temp_i < nConds(); _temp_i ++){
					predicted_expr[_temp_i] *= beta;
				}
			}
			else if(objOption == PGP){
				window_score = -pgp( predicted_expr, stripe_expr, beta );
				//cout << "score for PGP = " << window_score << endl;
				//cout << "beta for PGP = " << beta << endl;
				for(int _temp_i = 0; _temp_i < nConds(); _temp_i ++){
					predicted_expr[_temp_i] *= beta;
				}
			}
			//cout << "Predicted expression times beta: " << endl;
			//cout << predicted_expr << endl;
			//update the list of candidate stripes if necessary
			for( int k = 0; k < n_window_per_stripe; k++ ){
				if( best_window_score[j][k] < DBL_MAX ){
					if( best_window_score[j][k] > window_score ){
						for( int l = n_window_per_stripe - 1; l > k; l-- ){
							best_window_loc[j][l] = best_window_loc[j][l-1];
							best_window_len[j][l] = best_window_len[j][l-1];
							best_window_score[j][l] = best_window_score[j][l-1];
							best_window_expr[j][l] = best_window_expr[j][l-1];
						}
						best_window_loc[j][k] = start;
						best_window_len[j][k] = window_len;
						best_window_score[j][k] = window_score;
						best_window_expr[j][k] = predicted_expr;
						break;
					}
				}
				else{
					best_window_loc[j][k] = start;
					best_window_len[j][k] = window_len;
					best_window_score[j][k] = window_score;
					best_window_expr[j][k] = predicted_expr;
					break;
				}
			}
			//cout << "Candidate windows:" << endl;
			//cout << "Loc\tLen\tScore" << endl;
			/*for( int k = 0; k < n_window_per_stripe; k++ ){
				cout << best_window_loc[j][k] << "\t" << best_window_len[j][k] << "\t" << best_window_score[j][k] << endl;
			}*/
		}				
	}
    }
		
		//step 2: iteratively fit window weights
		vector < vector < double > > soln_window_expr;
		vector < int > soln_window_loc;
		vector < int > soln_window_len;
		vector < double > soln_window_weights;
		double temp_soln_score = DBL_MAX;
		double soln_score = DBL_MAX;
		bool soln_found = false;
		for( int j = 0; j < n_stripe( i ); j++ ){//consider each stripe of the i-th gene
			//cout << "Started working for stripe: " << j << endl;
			cur_target_expr.clear();
			for( int _temp_i = 0; _temp_i < nConds(); _temp_i++ )
				cur_target_expr.push_back( 0 );
			add_expr(i, 0, j, cur_target_expr);
			//cout << "Current target expression: " << endl;
			//cout << cur_target_expr << endl;
			for( int k = 0; (k <  n_window_per_stripe) && (best_window_loc[j][k] >= 0); k++ ){
				//cout << "Testing:: stripe: " << j << " window: " << k << endl;
				//consider each candidate window of the j-th stripe of the i-th gene
				temp_soln_window_expr = soln_window_expr;
				temp_soln_window_expr.push_back( best_window_expr[j][k] );
				//add the k-th window of the j-th stripe to the current candidate solution
				vector < double > temp_soln_window_weights( temp_soln_window_expr.size(), 0 );
				train_window_weights( i, temp_soln_window_weights, temp_soln_score );
				//cout << "Current estimate of window weights: " << endl;
				/*for( int _temp_i = 0; _temp_i < temp_soln_window_weights.size(); _temp_i++ ){
					cout << temp_soln_window_weights[ _temp_i ] << "\t";
				}
				cout << endl;
				cout << "Score for current solution: " << temp_soln_score << endl;*/
				if( !soln_found ){
					assert( !( soln_score < DBL_MAX ) );
					//cout << "Recording the first solution:" << endl;
					//if( temp_soln_score < soln_score ){
					soln_window_expr.push_back(best_window_expr[j][k]);
					//cout << "Number of widows: " << soln_window_expr.size() << ", score: " << temp_soln_score << endl;
					/*for( int __temp_i = 0; __temp_i < soln_window_expr.size(); __temp_i ++ ){
						cout << "Window: " << __temp_i << endl;
						cout << soln_window_expr[ __temp_i ] << endl;
					}*/
					soln_window_loc.push_back(best_window_loc[j][k]);
					soln_window_len.push_back(best_window_len[j][k]);
					soln_window_weights = temp_soln_window_weights;
					soln_score = temp_soln_score;

					soln_found = true;
					//}
				}
				else if ( temp_soln_score < soln_score ){
					//cout << "Recording a new best solution:" << endl;
					soln_window_expr.push_back(best_window_expr[j][k]);
					//cout << "Number of widows: " << soln_window_expr.size() << ", score: " << temp_soln_score << endl;
					/*for( int __temp_i = 0; __temp_i < soln_window_expr.size(); __temp_i ++ ){
						cout << "Window: " << __temp_i << endl;
						cout << soln_window_expr[ __temp_i ] << endl;
					}*/
					soln_window_loc.push_back(best_window_loc[j][k]);
					soln_window_len.push_back(best_window_len[j][k]);
					soln_window_weights = temp_soln_window_weights;
					soln_score = temp_soln_score;
				}
			}
		}
		//cout << "Computing final expr ..." << endl;
		for( int j = 0; j < nConds(); j++ ){
			for( int k = 0; k < soln_window_expr.size(); k++ ){
				final_predicted_exprs[j] += soln_window_weights[k] * soln_window_expr[k][j];
			}
		}
		cout << "Final expr:" << endl;
		cout << final_predicted_exprs << endl;
		for(int k = 0; k < soln_window_expr.size(); k++ ){
			cout << "Window:\t" << k << "\t";
			cout << soln_window_loc[k] << "\t" <<  soln_window_len[k] << "\t" << soln_window_weights[k] << endl;
			/*for( int j = 0; j < nConds(); j++ ){
				cout << soln_window_expr[k][j] << "\t";
			}
			cout << endl;*/
		}
	delete func;
}

double window_weight_objective_function( const gsl_vector* v, void *par )
{
	ExprPredictor* predictor = (ExprPredictor*)par;
	int _index = predictor -> cur_gene_index;
	vector < double > temp_cur_soln( predictor->nConds(), 0 );
	vector < double > temp_window_weights = gsl2vector(v);
	for( int _temp_i = 0; _temp_i < temp_window_weights.size(); _temp_i++ ) {
		assert( !(gsl_vector_get(v, _temp_i) != temp_window_weights[ _temp_i ]));
		temp_window_weights[ _temp_i ] = exp(inverse_infty_transform ( gsl_vector_get(v, _temp_i),
									log( ExprPar::min_window_weight ), 
									log( ExprPar::max_window_weight )
									));
	} 

	//cout << "Window weights estimated for computing objective function: " << endl;
	//cout << temp_window_weights << endl;
	
	vector < double > observedExprs = predictor -> cur_target_expr;
	for( int i = 0; i < predictor->nConds(); i++ ){
		for( int j = 0; j < predictor->temp_soln_window_expr.size(); j++ ){
			temp_cur_soln[i] += temp_window_weights[j] * predictor->temp_soln_window_expr[j][i];
		}
		//double observed = predictor->exprData( _index, i );
		//observedExprs.push_back( observed );
	}
	
	//cout << "Window expressions being used in this computation: " << endl;
	//for( int i = 0; i < predictor->temp_soln_window_expr.size(); i++ )
	//	cout << predictor->temp_soln_window_expr[i] << endl;

	//cout << "Weighted summation of expression being evaluated: " << endl;
	//cout << temp_cur_soln << endl;
	//cout << "Evaluated against: " << endl;
	//cout << observedExprs << endl;
	double score, beta;
	if(predictor->objOption == SSE){
		double sse_score = least_square( temp_cur_soln, observedExprs, beta );
		score = sqrt(sse_score/predictor->nConds());
	}
	else if(predictor->objOption == CORR){
		score = -corr( temp_cur_soln, observedExprs );
	}
	else if(predictor->objOption == PGP){
		score = -pgp( temp_cur_soln, observedExprs, beta );
	}
	//cout << "Score: " << score << endl;
	return score;
}

int ExprPredictor::train_window_weights( int i, vector < double >& temp_soln_window_weights, double& temp_soln_score )
{
	int n_cur_windows = temp_soln_window_expr.size();
	
	const gsl_multimin_fminimizer_type *T = gsl_multimin_fminimizer_nmsimplex2;
	gsl_multimin_fminimizer *s = NULL;
	gsl_vector *ss, *x;
	gsl_multimin_function minex_func;

	size_t iter = 0;
	int status;
	double size;

	/* Starting point */
	x = gsl_vector_alloc (n_cur_windows);
	for( int _i = 0; _i < n_cur_windows; _i++ ){
		temp_soln_window_weights[ _i ] = ExprPar::default_window_weight;
		
		gsl_vector_set (x, _i, 
			infty_transform(log( temp_soln_window_weights[_i] ), log( ExprPar::min_window_weight ), log( ExprPar::max_window_weight ))
			);
	}
	//cout << "Computing score before starting optimization of window weights: " << endl;
	temp_soln_score = window_weight_objective_function( x, (void*) this );
	//cout << "Computed score: " << temp_soln_score << endl;
	/* Set initial step sizes to 1 */
	ss = gsl_vector_alloc (n_cur_windows);
	gsl_vector_set_all (ss, 1.0);

	/* Initialize method and iterate */
	minex_func.n = n_cur_windows;
	minex_func.f = window_weight_objective_function;
	minex_func.params = (void*) this;

	s = gsl_multimin_fminimizer_alloc (T, n_cur_windows);
	gsl_multimin_fminimizer_set (s, &minex_func, x, ss);
	
	bool early_terminate = false;

	do
    	{
		iter++;
		status = gsl_multimin_fminimizer_iterate(s);
      
		if (status) 
			break;
		
		vector < double > cur_estimate_of_window_weights ( temp_soln_window_weights.size(), 0 );
		vector < double > temp_ = gsl2vector( s -> x );
		for( int _temp_i = 0; _temp_i < temp_.size(); _temp_i++ ) {
			double val_ = exp(inverse_infty_transform ( temp_[ _temp_i ],
									log( ExprPar::min_window_weight ), 
									log( ExprPar::max_window_weight )
									));
			if( val_ < ExprPar::min_window_weight*(1+ExprPar::delta) || val_ > ExprPar::max_window_weight*(1.0 - ExprPar::delta) ){
				//cout << "Window weight estimated at extreme value" << endl;
				early_terminate = true;
				break;
			}
			cur_estimate_of_window_weights[ _temp_i ] = val_;
		}	 
		
		if( early_terminate )
			break;

		temp_soln_window_weights = cur_estimate_of_window_weights;
		//cout << "Updated estimates for window weights: " << temp_soln_window_weights << endl;
		temp_soln_score = window_weight_objective_function( s->x, (void*) this );
		
		//cout << "Corresponding score: " << temp_soln_score << endl;

		assert( !(temp_soln_score != s->fval) );

		size = gsl_multimin_fminimizer_size (s);
		status = gsl_multimin_test_size (size, 1e-2);
		
		/*if (status == GSL_SUCCESS)
        	{
			//printf ("converged to minimum at\n");
        	}*/
    	} while (status == GSL_CONTINUE && iter < window_train_iter);
  
  
	gsl_vector_free(x);
	gsl_vector_free(ss);
	gsl_multimin_fminimizer_free (s);
	return status;
}

int ExprPredictor::simplex_minimize( ExprPar& par_result, double& obj_result )
{
    vector < double > pars;
    par_model.getFreePars( pars, coopMat, actIndicators, repIndicators );
    int pars_size = pars.size();
    fix_pars.clear();
    free_pars.clear();
    for( int index = 0; index < pars_size; index++ )
    {
        if( indicator_bool[ index ] )
        {
            free_pars.push_back( pars[ index ]);
        }
        else
        {
            fix_pars.push_back( pars[ index ] );
        }
    }

    pars.clear();
    pars = free_pars;

    //set the objective function
    gsl_multimin_function my_func;
    my_func.f = &gsl_obj_f;
    my_func.n = pars.size();
    my_func.params = (void*)this;

    // set the initial values to be searched
    gsl_vector* x = vector2gsl( pars );

	// choose the method of optimization and set its parameters
    const gsl_multimin_fminimizer_type* T = gsl_multimin_fminimizer_nmsimplex;
    gsl_vector* ss = gsl_vector_alloc( my_func.n );
    gsl_vector_set_all( ss, 1.0 );

    // create the minimizer
    gsl_multimin_fminimizer* s = gsl_multimin_fminimizer_alloc( T, my_func.n );
    gsl_multimin_fminimizer_set( s, &my_func, x, ss );

    // iteration
    size_t iter = 0;
    int status;
    double size;
    do
    {
        double f_prev = iter ? s->fval : 1.0E6;   // the function starts with some very large number

        iter++;
        status = gsl_multimin_fminimizer_iterate( s );

        // check for error
        if ( status ) break;
        //Hassan start:
        free_pars = gsl2vector( s-> x);
        pars.clear();
        int free_par_counter = 0;
        int fix_par_counter = 0;
        for( int index = 0; index < pars_size; index ++ )
        {
            if( indicator_bool[ index ] )
            {
                pars.push_back( free_pars[ free_par_counter ++ ]);
            }
            else
            {
                pars.push_back( fix_pars[ fix_par_counter ++ ]);
            }
        }
        ExprPar par_curr = ExprPar ( pars, coopMat, actIndicators, repIndicators, nSeqs(), par_model );
        if ( ExprPar::searchOption == CONSTRAINED && !testPar( par_curr ) ) break;

        size = gsl_multimin_fminimizer_size( s );
        status = gsl_multimin_test_size( size, 1e-1 );
        cout << iter << "\t";
        printPar( par_curr );
        printf( "\tf() = %8.5f size = %.3f\n", s->fval, size );
    } while ( status == GSL_CONTINUE && iter < nSimplexIters );

    free_pars = gsl2vector( s-> x);
    pars.clear();
    int free_par_counter = 0;
    int fix_par_counter = 0;
    for( int index = 0; index < pars_size; index ++ )
    {
        if( indicator_bool[ index ] )
        {
            pars.push_back( free_pars[ free_par_counter ++ ]);
        }
        else
        {
            pars.push_back( fix_pars[ fix_par_counter ++ ]);
        }
    }
    par_result = ExprPar ( pars, coopMat, actIndicators, repIndicators, nSeqs(), par_model );
    printPar( par_result );
    obj_result = s->fval;

    // free the minimizer
    gsl_vector_free( x );
    gsl_vector_free( ss );
    gsl_multimin_fminimizer_free( s );

    return 0;
}


int ExprPredictor::gradient_minimize( ExprPar& par_result, double& obj_result )
{
    vector< double > pars;
    par_model.getFreePars( pars, coopMat, actIndicators, repIndicators );
    int pars_size = pars.size();
    fix_pars.clear();
    free_pars.clear();
    for( int index = 0; index < pars_size; index++ )
    {
        if( indicator_bool[ index ] )
        {
            free_pars.push_back( pars[ index ]);
        }
        else
        {
            fix_pars.push_back( pars[ index ] );
        }
    }

    pars.clear();
    pars = free_pars;
    gsl_multimin_function_fdf my_func;
    my_func.f = &gsl_obj_f;
    my_func.df = &gsl_obj_df;
    my_func.fdf = &gsl_obj_fdf;
    my_func.n = pars.size();
    my_func.params = (void*)this;

    gsl_vector* x = vector2gsl( pars );

    const gsl_multimin_fdfminimizer_type* T = gsl_multimin_fdfminimizer_vector_bfgs;

    gsl_multimin_fdfminimizer* s = gsl_multimin_fdfminimizer_alloc( T, my_func.n );
    double init_step = 0.02, tol = 0.1;
    gsl_multimin_fdfminimizer_set( s, &my_func, x, init_step, tol );

    // iteration
    size_t iter = 0;
    int status;
    do
    {
        double f_prev = iter ? s->f : 1.0E6;      // the function starts with some very large number

        iter++;
        status = gsl_multimin_fdfminimizer_iterate( s );
        if ( status ) break;

        free_pars = gsl2vector( s-> x);
        pars.clear();
        int free_par_counter = 0;
        int fix_par_counter = 0;
        for( int index = 0; index < pars_size; index ++ )
        {
            if( indicator_bool[ index ] )
            {
                pars.push_back( free_pars[ free_par_counter ++ ]);
            }
            else
            {
                pars.push_back( fix_pars[ fix_par_counter ++ ]);
            }
        }

        ExprPar par_curr = ExprPar ( pars, coopMat, actIndicators, repIndicators, nSeqs(), par_model );
        if ( ExprPar::searchOption == CONSTRAINED && !testPar( par_curr ) ) break;

        double f_curr = s->f;
        double delta_f = abs( f_curr - f_prev );
        if ( objOption == SSE && delta_f < min_delta_f_SSE ) break;
        if ( objOption == CORR && delta_f < min_delta_f_Corr ) break;
        if ( objOption == PGP && delta_f < min_delta_f_PGP ) break;

        status = gsl_multimin_test_gradient( s->gradient, 5e-4 );
        cout << iter << "\t";
        printPar( par_curr );
        printf( "\tf() = %8.5f\n", s->f );
    } while ( status == GSL_CONTINUE && iter < nGradientIters );

    free_pars = gsl2vector( s-> x);
    pars.clear();
    int free_par_counter = 0;
    int fix_par_counter = 0;
    for( int index = 0; index < pars_size; index ++ )
    {
        if( indicator_bool[ index ] )
        {
            pars.push_back( free_pars[ free_par_counter ++ ]);
        }
        else
        {
            pars.push_back( fix_pars[ fix_par_counter ++ ]);
        }
    }

    par_result = ExprPar ( pars, coopMat, actIndicators, repIndicators, nSeqs(), par_model );
    obj_result = s->f;

    gsl_vector_free( x );
    gsl_multimin_fdfminimizer_free( s );

    return 0;
}


double gsl_obj_f( const gsl_vector* v, void* params )
{
    ExprPredictor* predictor = (ExprPredictor*)params;

    vector <double> temp_free_pars = gsl2vector(v);
    vector < double > all_pars;
    all_pars.clear();
    int free_par_counter = 0;
    int fix_par_counter = 0;
    for( int index = 0; index < predictor -> indicator_bool.size(); index ++ )
    {
        if( predictor ->  indicator_bool[ index ]  )
        {
            all_pars.push_back( temp_free_pars[ free_par_counter ++ ]  );
        }
        else
        {
            all_pars.push_back( predictor ->  fix_pars[ fix_par_counter ++ ]  );
        }
    }

    ExprPar par( all_pars, predictor->getCoopMat(), predictor->getActIndicators(), predictor->getRepIndicators(), predictor -> nSeqs(), predictor->getPar() );
    double obj = predictor->objFunc( par );
    return obj;
}

void gsl_obj_df( const gsl_vector* v, void* params, gsl_vector* grad )
{
    double step = 1.0E-3;
    numeric_deriv( grad, gsl_obj_f, v, params, step );
}


void gsl_obj_fdf( const gsl_vector* v, void* params, double* result, gsl_vector* grad )
{
    *result = gsl_obj_f( v, params );
    gsl_obj_df( v, params, grad );
}
